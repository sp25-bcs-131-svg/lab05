public class Demotest{
	public static void main(String args[]){

	//Seat s1=new Seat(2,3,SeatType.PREMIUM,true,500);
	//System.out.println(s1.toString());
	Screen s = new Screen (" Screen number 1 " );
	s.displayDetailed();
	}
}